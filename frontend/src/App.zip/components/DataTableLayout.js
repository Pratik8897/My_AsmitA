import { useState } from "react";
import "./DataTableLayout.css";

const DataTableLayout = ({
  title = "Table Title",
  columns = [],
  data = [],
  filters = null,
  searchPlaceholder = "Search...",
  onSearch = () => {},
  showFilterButton = true,
}) => {
  const [showFilters, setShowFilters] = useState(false);

  return (
    <div className="data-card">
      <div className="data-card-header">
        <div className="data-card-top">
          <h2>{title}</h2>

          {showFilterButton && filters ? (
            <button
              className="filter-toggle"
              type="button"
              onClick={() => setShowFilters((prev) => !prev)}
              aria-expanded={showFilters}
            >
              {showFilters ? "Hide Filters" : "Filters"}
            </button>
          ) : null}
        </div>

        <div className="data-filters-search">
        {filters ? (
            <div className={`data-filters${showFilters ? " open" : ""}`}>
            {filters}
            </div>
        ) : null}

        <div className="data-search">
            <span className="search-icon" aria-hidden="true" />
            <input
            placeholder={searchPlaceholder}
            onChange={(e) => onSearch(e.target.value)}
            />
        </div>
        </div>
      </div>

      <div className="data-table">
        <table>
          <thead>
            <tr>
              {columns.map((col) => (
                <th key={col.key}>{col.label}</th>
              ))}
            </tr>
          </thead>

          <tbody>
            {data.length > 0 ? (
              data.map((row, index) => (
                <tr key={row.id || index}>
                  {columns.map((col) => (
                    <td key={col.key} data-label={col.label}>
                      {col.render ? col.render(row, index) : row[col.key]}
                    </td>
                  ))}
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={columns.length} style={{ textAlign: "center" }}>
                  No Data Found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DataTableLayout;